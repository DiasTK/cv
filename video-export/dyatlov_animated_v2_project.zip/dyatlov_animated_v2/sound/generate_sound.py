#!/usr/bin/env python3
"""Original 72-second winter sound design, synthesized without external audio.

Eighteen four-second shots. The first two groups have deliberate footstep and
cloth cues; later sections alternate forest movement, search details, and wind.
"""
from pathlib import Path
import json
import wave
import numpy as np
from scipy.signal import butter, sosfilt

ROOT = Path(__file__).resolve().parent
SR, SECONDS = 48_000, 72
N = SR * SECONDS
rng = np.random.default_rng(19590202)
t = np.arange(N, dtype=np.float64) / SR
audio = np.zeros((N, 2), dtype=np.float64)
cues = []


def noise(count, low, high):
    s = sosfilt(butter(3, [low, high], btype="bandpass", fs=SR,
                       output="sos"), rng.standard_normal(count))
    return s / (np.sqrt(np.mean(s*s)) + 1e-12)


def add(at, s, pan=0.0, label="foley"):
    start = round(at * SR)
    count = min(len(s), N - start)
    # Equal-power pan, subtle stereo reflection, no wide phase cancellation.
    l = np.sqrt((1 - pan) / 2)
    r = np.sqrt((1 + pan) / 2)
    audio[start:start+count, 0] += s[:count] * l
    audio[start:start+count, 1] += s[:count] * r
    delay = round(0.037 * SR)
    end = min(N, start + count + delay)
    refl_n = end - start - delay
    if refl_n > 0:
        audio[start+delay:end, 0] += s[:refl_n] * r * 0.13
        audio[start+delay:end, 1] += s[:refl_n] * l * 0.13
    cues.append({"time": at, "duration": round(len(s)/SR, 3), "type": label})


# Cold, band-limited wind: three independent layers rather than loud white hiss.
arc = np.interp(t, [0, 4, 8, 12, 16, 24, 32, 36, 40, 44, 48, 56, 60, 64, 72],
                [.62, .72, .56, .48, .74, .64, .42, .34, .35, .78, 1.0, .83, .68, .62, .40])
gust = .75 + .18*np.sin(t*.49+.2) + .10*np.sin(t*1.13)
body = noise(N, 70, 860) * arc * gust
air_l = noise(N, 650, 3500)
air_r = noise(N, 650, 3500)
pan = .12*np.sin(t*.18)
audio[:, 0] = .032*body*(1+pan) + .0055*air_l*arc*gust
audio[:, 1] = .032*body*(1-pan) + .0055*air_r*arc*gust
# Very low harmonic bed, kept below the foley.
drone = (.011*np.sin(2*np.pi*49*t+.22*np.sin(t*.10))
         + .006*np.sin(2*np.pi*73.416*t+.15*np.sin(t*.13))
         + .0025*np.sin(2*np.pi*98*t))
drone *= arc*(.70+.15*np.sin(t*.35))
audio += drone[:, None]


def snow_step(at, strength=1.0, pan=0.0, duration=.47):
    n = round(duration*SR)
    u = np.arange(n)/SR
    # Compression under the sole, followed by irregular crystalline grains.
    sole = noise(n, 80, 430) * (1-np.exp(-u*180))*np.exp(-u*15)
    grain = noise(n, 1100, 7000)
    grain_env = np.zeros(n)
    for off, length, amp in [(0.012,.08,.8),(.071,.10,1),(.145,.13,.7),(.235,.17,.38)]:
        k = int(off*SR)
        count = min(int(length*SR), n-k)
        v = np.arange(count)/SR
        grain_env[k:k+count] += amp*np.sin(np.pi*v/length)**2
    grain *= grain_env*(.72+.28*np.sin(u*2*np.pi*41))
    s = strength*(.069*sole + .023*grain)
    add(at, s, pan, "snow footstep")


def cloth(at, duration=1.45, strength=1.0, pan=0.0):
    n = int(duration*SR)
    u = np.arange(n)/SR
    flutter = (.60+.19*np.sin(u*2*np.pi*8.3)+.13*np.sin(u*2*np.pi*17.6))
    env = np.sin(np.pi*u/duration)**2*flutter
    # Fine crinkles ride the low canvas flap, not a synthetic zipping sound.
    flap = noise(n, 110, 900)
    crinkle = noise(n, 900, 4400)
    granular = np.maximum(0, np.sin(u*2*np.pi*26.7+.8))**4
    s = strength*env*(.024*flap+.014*crinkle*(.35+granular))
    add(at, s, pan, "tent canvas rustle")


def switch(at, pan=0.0):
    n = int(.11*SR)
    u = np.arange(n)/SR
    s = .017*noise(n, 800, 6000)*(1-np.exp(-u*700))*np.exp(-u*65)
    add(at, s, pan, "flashlight switch")


def low_pulse(at, strength=1.0):
    n = int(1.65*SR)
    u = np.arange(n)/SR
    s = .027*strength*np.sin(2*np.pi*(57*u-1.9*u*u))
    s *= (1-np.exp(-u*50))*np.exp(-u*3.1)
    add(at, s, 0, "soft low beat")


def wash(at, duration=1.6, strength=.012):
    n = int(duration*SR)
    u = np.arange(n)/SR
    s = noise(n, 140, 1900)*np.sin(np.pi*u/duration)**2*strength
    add(at, s, -.15, "wind transition")


def paper(at, duration=.85, pan=-.18):
    n = int(duration*SR)
    u = np.arange(n)/SR
    env = np.sin(np.pi*u/duration)**2
    flutter = .55+.30*np.sin(2*np.pi*22*u)+.15*np.sin(2*np.pi*57*u)
    s = .010*noise(n, 650, 5100)*env*flutter
    s += .005*noise(n, 120, 740)*env
    add(at, s, pan, "quiet paper page turn")


def ink(at, duration=.26):
    n = int(duration*SR)
    u = np.arange(n)/SR
    s = .007*noise(n, 350, 2700)*np.sin(np.pi*u/duration)**2
    s *= .7+.3*np.sin(2*np.pi*29*u)
    add(at, s, .14, "small ink marker stroke")


def snow_rumble(at, duration=3.2):
    n = int(duration*SR)
    u = np.arange(n)/SR
    s = .009*noise(n, 38, 240)*np.sin(np.pi*u/duration)**2
    add(at, s, -.08, "restrained distant snow rumble")


# 0–8 s: arrival in snow. Alternate boot positions with natural uneven cadence.
for i, at in enumerate([.48, 1.54, 2.61, 3.60, 4.69, 5.73, 6.88]):
    snow_step(at, .92+rng.uniform(-.10,.10), -.24 if i%2 == 0 else .24)
# 8–16 s: close tent fabric and one muted movement under the canvas.
for at, dur, strength, pan_ in [(8.18,1.55,1.1,-.35),(10.22,1.32,.85,.20),
                                (12.10,1.62,1.15,.31),(14.30,1.40,.8,-.20)]:
    cloth(at, dur, strength, pan_)
snow_step(11.60, .42, -.10, .43)
# 16–24 s: tracks leading into forest. More distant, lighter steps.
for i, at in enumerate([16.54,17.70,18.96,20.20,21.50,22.83]):
    snow_step(at, .55, .18 if i%2 else -.18)
# 24–32 s: searchers and moving flashlight, intermittent footfalls and coat cloth.
for at, pan_ in [(24.25,-.28),(29.20,.24),(60.25,-.15)]:
    switch(at, pan_)
for i, at in enumerate([25.35,26.59,28.02,30.28,31.45]):
    snow_step(at, .58+.10*(i%3), -.30 if i%2 else .28)
for at in [27.45]:
    cloth(at, .72, .38, -.12)
# 32–44 s: document inserts, dry desk foley rather than outdoor footsteps.
for at, dur in [(32.23,.85),(35.00,.70),(36.17,.90),(39.10,.65),(40.18,1.05),(43.05,.50)]:
    paper(at, dur)
for at in [33.55,37.65,41.65]:
    ink(at)
# 44–60 s: snow slab and model inserts; subdued low snow motion under wind.
for at in [44.3,52.2]:
    snow_rumble(at)
for at, strength in [(0.10,.65),(7.95,.55),(15.95,.62),(23.95,.65),
                     (43.95,.75),(47.95,.78),(55.95,.50),(63.95,.38)]:
    low_pulse(at, strength)
for at, duration, level in [(7.1,1.5,.008),(15.0,1.8,.010),
                            (23.0,1.8,.009),(43.0,2.2,.012),
                            (46.9,2.5,.018),(54.9,2.2,.012),(62.9,2.0,.008)]:
    wash(at, duration, level)
# A few wind-borne crystals around the model sequences, then soft dawn wind.
for at, dur, strength in [(45.0,2.8,.28),(50.1,2.1,.30),(58.1,1.6,.20)]:
    cloth(at, dur, strength, .25)

fade = np.minimum(np.clip(t/1.05,0,1),np.clip((SECONDS-t)/3.8,0,1))
audio *= (np.sin(fade*np.pi/2)**2)[:, None]
audio *= 10**(-20/20)/np.sqrt(np.mean(audio**2))
peak_limit = 10**(-3/20)
if np.max(np.abs(audio)) > peak_limit:
    audio *= peak_limit/np.max(np.abs(audio))
pcm = np.rint(audio*32767).astype("<i2")
out = ROOT / "soundscape.wav"
with wave.open(str(out), "wb") as f:
    f.setnchannels(2)
    f.setsampwidth(2)
    f.setframerate(SR)
    f.writeframes(pcm.tobytes())
metrics = {
    "file":str(out),"duration_seconds":SECONDS,"sample_rate":SR,"channels":2,
    "encoding":"PCM signed 16-bit little endian",
    "peak_dbfs":float(20*np.log10(np.max(np.abs(audio)))),
    "rms_dbfs":float(20*np.log10(np.sqrt(np.mean(audio**2)))),
    "shot_seconds":4,"shot_count":18,
    "source":"Original deterministic synthesis; no external samples or narration",
    "cue_count":len(cues),"cues":sorted(cues,key=lambda c:c["time"])
}
(ROOT/"metrics.json").write_text(json.dumps(metrics,indent=2)+"\n")
print(json.dumps({k:v for k,v in metrics.items() if k != "cues"},indent=2))
