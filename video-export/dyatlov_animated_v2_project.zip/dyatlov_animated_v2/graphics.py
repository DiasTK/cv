"""Animated explanatory inserts for the Dyatlov short.

These are modern illustrations, not reproductions of historical documents.
Public render functions take local shot time in seconds and return Pillow RGB.
Only the image is rendered here; captions and editorial badges belong to caller.
"""

from functools import lru_cache
from pathlib import Path
import math

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont


_FONT_ROOT = Path(__file__).resolve().parent / "assets" / "fonts"
_LANCZOS = Image.Resampling.LANCZOS
_BICUBIC = Image.Resampling.BICUBIC


@lru_cache(maxsize=32)
def _font(size, serif=False):
    path = _FONT_ROOT / ("NotoSerif-Bold.ttf" if serif else "NotoSans-Regular.ttf")
    return ImageFont.truetype(str(path), max(9, int(size)))


def _smooth(v):
    v = min(1.0, max(0.0, v))
    return v * v * (3 - 2 * v)


def _text(draw, xy, text, size, fill, serif=False):
    draw.text(xy, text, font=_font(size, serif), fill=fill)


@lru_cache(maxsize=12)
def _background(w, h, kind):
    """Retained textured background, illumination and vignette, all secret-free."""
    rng = np.random.default_rng(6590 + kind)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    xn, yn = xx / w, yy / h
    noise = rng.normal(0, 1.4, (h, w)).astype(np.float32)
    if kind == 0:
        light = np.exp(-((xn - .43) ** 2 / .30 + (yn - .37) ** 2 / .19))
        grain = 2 * np.sin(xx * .05 + 1.3 * np.sin(yy * .003))
        rgb = np.stack([27 + 40 * light + grain + noise,
                        29 + 34 * light + grain * .6 + noise,
                        25 + 23 * light + noise], axis=-1)
    else:
        light = np.exp(-((xn - .58) ** 2 / .6 + (yn - .30) ** 2 / .20))
        rgb = np.stack([29 + 29 * light + noise,
                        39 + 34 * light + noise,
                        43 + 31 * light + noise], axis=-1)
    base = Image.fromarray(np.uint8(np.clip(rgb, 0, 255)), "RGB")
    radial = ((xn - .5) / .69) ** 2 + ((yn - .4) / .82) ** 2
    vig = np.clip(1 - .40 * radial, .23, 1)
    # The root's subtitle area remains visually calm and readable.
    bottom = 1 - .29 * np.clip((yn - .61) / .30, 0, 1)
    mul = np.uint8(np.clip(vig * bottom * 255, 0, 255))
    vignette = Image.fromarray(mul, "L").convert("RGB")
    if kind:
        d = ImageDraw.Draw(base)
        for j in range(4):
            p = []
            for x in range(-30, w + 31, 12):
                y = h * (.19 + .042 * j) + h * (.026 + j * .006) * math.sin(x / (w * .15) + j)
                p.append((x, y))
            p.extend([(w + 30, h * .62), (-30, h * .62)])
            d.polygon(p, fill=(40 + j * 5, 51 + j * 5, 53 + j * 5))
    return base, vignette


@lru_cache(maxsize=12)
def _paper(pw, ph, variant):
    rng = np.random.default_rng(900 + variant)
    yy, xx = np.mgrid[0:ph, 0:pw]
    n = rng.normal(0, 1.25, (ph, pw))
    wear = 8 * ((xx / pw - .5) ** 2 + (yy / ph - .5) ** 2)
    colors = np.stack([177 + n - wear, 171 + n - wear, 145 + n - wear], axis=-1)
    page = Image.fromarray(np.uint8(np.clip(colors, 0, 255)), "RGB").convert("RGBA")
    d = ImageDraw.Draw(page)
    sc = pw / 565
    ink = (48, 51, 43, 205)
    faint = (68, 68, 53, 90)
    margin = int(pw * .09)
    d.rectangle((margin, ph * .065, pw - margin, ph * .067), fill=ink)
    _text(d, (margin, ph * .09), "ТҮСІНДІРМЕ", 17 * sc, ink)
    _text(d, (margin, ph * .135), ["ДЕРЕК ПЕН БОЛЖАМ", "ДЕРЕКТЕРДІ САЛЫСТЫРУ", "1959 / ТЕРГЕУ ҚОРЫТЫНДЫСЫ"][variant], 20 * sc, ink, True)
    d.line((margin, ph * .192, pw - margin, ph * .192), fill=faint, width=1)

    # Fine contour lines suggest a working topographic sketch, not fake prose.
    for j in range(11):
        points = []
        for x in range(margin, pw - margin, 5):
            y = ph * (.28 + j * .028) + math.sin(x / (pw * .19) + j * .24) * ph * .028
            points.append((x, y))
        d.line(points, fill=(79, 80, 61, 88), width=max(1, round(sc)))
    if variant == 0:
        points = [(pw * .18, ph * .53), (pw * .38, ph * .42), (pw * .61, ph * .38), (pw * .79, ph * .29)]
        d.line(points, fill=(68, 64, 42, 165), width=max(1, int(2 * sc)))
        for x, y in points:
            d.ellipse((x - 4 * sc, y - 4 * sc, x + 4 * sc, y + 4 * sc), outline=ink, width=max(1, int(sc)))
        _text(d, (margin, ph * .62), "ДЕРЕК", 20 * sc, ink, True)
        _text(d, (pw * .60, ph * .62), "БОЛЖАМ", 20 * sc, ink, True)
        for row in range(5):
            y = ph * (.69 + row * .035)
            d.line((margin, y, pw * .42, y), fill=faint, width=max(1, int(sc)))
            d.line((pw * .60, y, pw * .85, y), fill=(93, 88, 61, 95), width=max(1, int(sc)))
    elif variant == 1:
        # A geometrical tent plan and two neutral evidence columns.
        x0, y0, x1, y1 = pw * .21, ph * .32, pw * .79, ph * .50
        d.polygon([(x0, y1), ((x0 + x1) / 2, y0), (x1, y1)], outline=ink, width=max(2, int(2 * sc)))
        d.line(((x0 + x1) / 2, y0, (x0 + x1) / 2, y1), fill=faint, width=1)
        d.line((pw * .5, ph * .50, pw * .5, ph * .58), fill=ink, width=1)
        d.line((pw * .24, ph * .58, pw * .76, ph * .58), fill=ink, width=1)
        _text(d, (pw * .13, ph * .63), "ДЕРЕК", 20 * sc, ink, True)
        _text(d, (pw * .61, ph * .63), "БОЛЖАМ", 20 * sc, ink, True)
        for j in range(4):
            y = ph * (.70 + j * .038)
            d.ellipse((pw * .14, y, pw * .14 + 3 * sc, y + 3 * sc), fill=ink)
            d.line((pw * .19, y + sc, pw * .42, y + sc), fill=faint, width=1)
            d.line((pw * .61, y + sc, pw * .85, y + sc), fill=faint, width=1)
    else:
        _text(d, (margin, ph * .28), "1959", 63 * sc, ink, True)
        _text(d, (margin, ph * .43), "ТАБИҒИ КҮШ", 25 * sc, ink, True)
        # Small physical forces diagram: snow-bearing slope and downslope arrow.
        d.polygon([(pw * .18, ph * .57), (pw * .80, ph * .73), (pw * .80, ph * .83), (pw * .18, ph * .83)], fill=(112, 111, 86, 45), outline=faint)
        d.line((pw * .30, ph * .57, pw * .65, ph * .66), fill=ink, width=max(2, int(2 * sc)))
        d.line((pw * .65, ph * .66, pw * .60, ph * .62), fill=ink, width=max(2, int(2 * sc)))
        d.line((pw * .65, ph * .66, pw * .58, ph * .67), fill=ink, width=max(2, int(2 * sc)))
    _text(d, (margin, ph * .925), "ҚАЗІРГІ ТҮСІНДІРМЕ / АРХИВ ЕМЕС", 12 * sc, (63, 64, 51, 160))
    return page


def _finish(image, w, h, kind):
    return ImageChops.multiply(image.convert("RGB"), _background(w, h, kind)[1])


@lru_cache(maxsize=24)
def _rotated_paper(pw, ph, variant, angle_key):
    page = _paper(pw, ph, variant).rotate(angle_key / 10, resample=_BICUBIC, expand=True)
    mask = page.getchannel("A").filter(ImageFilter.GaussianBlur(max(2, pw / 40)))
    return page, mask


@lru_cache(maxsize=4)
def _lamp(w, h):
    glow = Image.new("RGBA", (round(w * 1.5), round(h * .9)))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((w * .08, h * .02, w * 1.3, h * .82), fill=(194, 172, 111, 15))
    return glow.filter(ImageFilter.GaussianBlur(55 * w / 720))


def render_document(t, variant, w=720, h=1280):
    """Moving, lit physical case-paper illustration; variant 0, 1 or 2."""
    variant = int(variant) % 3
    t = max(0.0, float(t))
    base = _background(w, h, 0)[0].copy().convert("RGBA")
    pw, ph = round(w * .82), round(h * .62)
    sc = w / 720
    angle_key = round(((-4.0 + variant * 2.0) + 1.2 * math.sin(.48 * t + variant * .4)) * 10)
    page, mask = _rotated_paper(pw, ph, variant, angle_key)
    x = round((w - page.width) / 2 + math.sin(.52 * t) * 10 * sc)
    yy = round(h * .14 + math.sin(.72 * t + variant) * 7 * sc)
    shadow = Image.new("RGBA", base.size)
    shadow.paste((0, 0, 0, 125), (x + round(14 * sc), yy + round(22 * sc)), mask)
    base.alpha_composite(shadow)
    base.alpha_composite(page, (x, yy))
    overlay = Image.new("RGBA", base.size)
    d = ImageDraw.Draw(overlay)
    angle = math.radians(angle_key / 10)
    co, si = math.cos(angle), math.sin(angle)
    def point(lx, ly):
        dx, dy = lx - pw / 2, ly - ph / 2
        return x + page.width / 2 + co * dx + si * dy, yy + page.height / 2 - si * dx + co * dy
    # A warm highlight actively travels across selected evidence without quoting it.
    sweep = .28 + .49 * _smooth((t - .10) / 3.5)
    y = ph * sweep
    d.polygon([point(pw * .08, y - 9 * sc), point(pw * .89, y - 9 * sc),
               point(pw * .89, y + 12 * sc), point(pw * .08, y + 12 * sc)], fill=(204, 167, 66, 42))
    d.line([point(pw * .08, y + 12 * sc), point(pw * .89, y + 12 * sc)], fill=(108, 90, 35, 80), width=max(1, round(sc)))
    # Page corner physically lifts and casts its own moving shadow.
    curl = (20 + 25 * (.5 + .5 * math.sin(t * 1.6 + variant))) * sc
    d.polygon([point(pw - curl, ph), point(pw, ph - curl * 1.3), point(pw - curl * .12, ph - curl * .15)], fill=(119, 115, 94, 125))
    d.polygon([point(pw - curl, ph), point(pw - curl * .65, ph - curl * .92), point(pw, ph - curl * 1.3)], fill=(202, 197, 169, 245))
    base.alpha_composite(overlay)
    # Moving lamp pool, separate from page movement, gives depth without flashing.
    glow = _lamp(w, h)
    base.alpha_composite(glow, (round(-w * .3 + 35 * sc * math.sin(t * .7)), round(h * .02)))
    return _finish(base, w, h, 0)


def _dashed_line(d, a, b, color, width, phase=0.0, dash=12):
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy)
    if length < 1:
        return
    p = -phase % (dash * 2) - dash * 2
    while p < length:
        lo, hi = max(0, p), min(length, p + dash)
        if hi > lo:
            d.line((a[0] + dx * lo / length, a[1] + dy * lo / length,
                    a[0] + dx * hi / length, a[1] + dy * hi / length), fill=color, width=width)
        p += dash * 2


def _arrow(d, a, b, color, width, head):
    d.line((*a, *b), fill=color, width=width)
    theta = math.atan2(b[1] - a[1], b[0] - a[0])
    p = (b[0] - head * math.cos(theta - .5), b[1] - head * math.sin(theta - .5))
    q = (b[0] - head * math.cos(theta + .5), b[1] - head * math.sin(theta + .5))
    d.polygon([b, p, q], fill=color)


def render_diagram(t, variant, w=720, h=1280):
    """Animated layered snow cross-section and explicitly uncertain model route."""
    t = max(0.0, float(t))
    variant = int(variant) % 2
    sc = w / 720
    base = _background(w, h, 1)[0].copy().convert("RGBA")
    overlay = Image.new("RGBA", (w, h))
    d = ImageDraw.Draw(overlay)
    _text(d, (w * .08, h * .145), "СХЕМА / ҒЫЛЫМИ МОДЕЛЬ", 16 * sc, (204, 210, 194, 180))

    # Fine spatial grid stays quieter than the actual animated physical layers.
    for x in range(round(w * .07), round(w * .95), max(12, round(55 * sc))):
        d.line((x, h * .23, x, h * .62), fill=(162, 182, 176, 16), width=1)
    for j in range(10):
        y = h * (.24 + j * .041)
        d.line((w * .06, y, w * .96, y), fill=(162, 182, 176, 16), width=1)

    # Cross section: all layers share the downhill slope but have different depth.
    left, right = w * .045, w * .95
    y0, y1 = h * .325, h * .545
    def y_at(x):
        return y0 + (x - left) / (right - left) * (y1 - y0)
    bottom = h * .68
    d.polygon([(left, y0 + h * .058), (right, y1 + h * .058),
               (right, bottom), (left, bottom)], fill=(69, 75, 67, 255))
    for j, color in enumerate([(125, 141, 140, 255), (163, 179, 173, 255), (196, 208, 196, 255)]):
        offset = h * (.049 - j * .014)
        thickness = h * .016
        pts = [(left, y0 + offset), (right, y1 + offset),
               (right, y1 + offset + thickness), (left, y0 + offset + thickness)]
        d.polygon(pts, fill=color)
        d.line([pts[0], pts[1]], fill=(215, 225, 209, 110), width=max(1, round(sc)))

    progress = _smooth((t - .3) / 3.4)
    shift = (20 + 55 * progress) * sc if not variant else (12 + 28 * progress) * sc
    slope = (y1 - y0) / (right - left)
    slab_left, slab_right = w * .12 + shift, w * .77 + shift
    top = [(slab_left, y_at(slab_left) - h * .016),
           (slab_right, y_at(slab_right) - h * .016),
           (slab_right, y_at(slab_right) + h * .014),
           (slab_left, y_at(slab_left) + h * .014)]
    d.polygon([(x + 7 * sc, y + 9 * sc) for x, y in top], fill=(0, 0, 0, 55))
    d.polygon(top, fill=(223, 229, 215, 255))
    d.line(top[:2], fill=(246, 247, 230, 230), width=max(2, round(3 * sc)))
    # The fracture propagates independently of camera/translation.
    crack_x = slab_left + w * .08
    crack_y = y_at(crack_x)
    crack_length = h * .043 * _smooth(t / 1.5)
    d.line([(crack_x, crack_y - h * .018), (crack_x + 5 * sc, crack_y - h * .009),
            (crack_x - 4 * sc, crack_y + crack_length)], fill=(58, 71, 70, 245), width=max(2, round(2 * sc)))

    # A small tent gives scale; it is schematic rather than a claim of exact geometry.
    tx = w * .67
    ty = y_at(tx) - h * .034
    d.polygon([(tx - w * .055, ty + h * .012), (tx, ty - h * .034),
               (tx + w * .065, ty + h * .036)], fill=(112, 113, 87, 245), outline=(212, 206, 171, 220))
    d.line((tx, ty - h * .034, tx + w * .005, ty + h * .024), fill=(45, 53, 47, 190), width=max(1, round(2 * sc)))

    # Direction cues travel rather than sitting as static slide arrows.
    ax = w * (.32 + .045 * math.sin(t * .8))
    ay = y_at(ax) - h * .095
    if variant == 0:
        _arrow(d, (ax, ay), (ax + w * .24, ay + w * .24 * slope),
               (198, 185, 132, 195), max(2, round(3 * sc)), 14 * sc)
    else:
        a = (w * .16, h * .25)
        b = (w * .83, h * .425)
        # Translucent band, offset paths and advancing dashed center show model limits.
        d.line((*a, *b), fill=(179, 176, 129, 21), width=max(8, round(62 * sc)))
        for off in (-23, 23):
            _dashed_line(d, (a[0], a[1] + off * sc), (b[0], b[1] + off * sc),
                         (172, 181, 160, 65), max(1, round(sc)), t * 13 * sc, 9 * sc)
        _dashed_line(d, a, b, (210, 197, 143, 220), max(2, round(3 * sc)), t * 22 * sc, 13 * sc)
        mark = (t * .235) % 1
        mx, my = a[0] + (b[0] - a[0]) * mark, a[1] + (b[1] - a[1]) * mark
        d.ellipse((mx - 5 * sc, my - 5 * sc, mx + 5 * sc, my + 5 * sc), fill=(226, 210, 151, 230))

    # Drift particles have individually seeded phases and velocity, not a uniform pan.
    for j in range(53):
        p = ((j * .61803398875) % 1)
        q = ((j * .41421356237 + .18) % 1)
        px = ((p + t * (.018 + (j % 6) * .004)) % 1) * w
        py = ((q + t * (.010 + (j % 4) * .004)) % .58) * h + h * .10
        radius = (.6 + (j % 3) * .35) * sc
        d.ellipse((px - radius, py - radius, px + radius, py + radius), fill=(227, 233, 219, 48 + j % 55))
    base.alpha_composite(overlay)
    return _finish(base, w, h, 1)
