#!/usr/bin/env python3
"""Cinematic layered animation: articulated hikers, cloth, snow, lights, models."""
from pathlib import Path
from functools import lru_cache
import argparse
import concurrent.futures
import json
import math
import subprocess
import time
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops, ImageEnhance

ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'assets'
OUT=ROOT/'output'
W,H,FPS=720,1280,24
TIMELINE=json.loads((ROOT/'timeline.json').read_text())

@lru_cache(maxsize=20)
def font(size,serif=False):
    return ImageFont.truetype(str(ASSETS/'fonts'/('NotoSerif-Bold.ttf' if serif else 'NotoSans-Regular.ttf')),size)

def cover(im,size=(W,H)):
    w,h=size
    scale=max(w/im.width,h/im.height)
    im=im.resize((math.ceil(im.width*scale),math.ceil(im.height*scale)),Image.Resampling.LANCZOS)
    x,y=(im.width-w)//2,(im.height-h)//2
    return im.crop((x,y,x+w,y+h))

@lru_cache(maxsize=8)
def photo(name):
    return cover(Image.open(ASSETS/(name+'.png')).convert('RGB'))

@lru_cache(maxsize=1)
def vignette():
    yy,xx=np.mgrid[:H,:W]
    rr=((xx-W/2)/(W*.75))**2+((yy-H*.47)/(H*.76))**2
    alpha=np.clip(rr*58,0,105)+np.maximum(0,(yy-H*.68)/(H*.32))*38
    a=np.zeros((H,W,4),dtype=np.uint8)
    a[:,:,3]=np.clip(alpha,0,125).astype('uint8')
    return Image.fromarray(a)

@lru_cache(maxsize=1)
def fog_texture():
    rng=np.random.default_rng(1959)
    noise=rng.integers(0,255,(24,80),dtype=np.uint8)
    a=Image.fromarray(noise).resize((W*3,420),Image.Resampling.BICUBIC).filter(ImageFilter.GaussianBlur(30))
    vals=np.asarray(a,dtype=np.float32)
    edge=np.sin(np.linspace(0,math.pi,420))[:,None]**1.3
    rgba=np.zeros((420,W*3,4),dtype=np.uint8)
    rgba[:,:,:3]=(172,186,194)
    rgba[:,:,3]=np.clip((vals-60)*.22*edge,0,30).astype('uint8')
    return Image.fromarray(rgba)

@lru_cache(maxsize=1)
def snow_particles():
    rng=np.random.default_rng(2000)
    return [(float(rng.uniform(-300,W)),float(rng.uniform(0,H)),float(rng.uniform(.25,1)),float(rng.uniform(0,6))) for _ in range(260)]

def camera(im,t,shot):
    z=1.035+.013*t
    # A distinct camera track per shot, independent of object and weather motion.
    dx=11*math.sin(t*.28+shot*.7)
    dy=6*math.sin(t*.33+shot)
    return im.transform((W,H),Image.Transform.AFFINE,(1/z,0,W/2-W/(2*z)+dx,0,1/z,H/2-H/(2*z)+dy),Image.Resampling.BILINEAR)

def snow(im,t,strength=1,near=True):
    layer=Image.new('RGBA',(W,H))
    d=ImageDraw.Draw(layer)
    count=int(190*strength)
    for x0,y0,z,phase in snow_particles()[:min(260,count)]:
        speed=(95+110*z)*strength
        x=(x0+t*speed+13*math.sin(t*1.2+phase))%(W+80)-40
        y=(y0+t*(18+30*z))%(H+50)-25
        alpha=int((46+95*z)*min(strength,1.4))
        length=(2+8*z)*strength
        d.line((x,y,x+length,y+length*.28),fill=(214,227,235,alpha),width=1 if z<.75 else 2)
    if near:
        # Large out-of-focus flakes cross the frame much faster than the horizon.
        for x0,y0,z,phase in snow_particles()[220:244]:
            x=(x0+t*(290+z*120))%(W+140)-70
            y=(y0+t*(75+z*90))%(H+100)-50
            d.ellipse((x,y,x+2+z*3,y+1+z*2),fill=(203,221,231,80))
    return Image.alpha_composite(im.convert('RGBA'),layer)

def fog(im,t,y=570,opacity=1):
    texture=fog_texture()
    x=int((t*38)%(W*1.8))
    f=texture.crop((x,0,x+W,420))
    if opacity!=1:
        f.putalpha(f.getchannel('A').point(lambda x:int(x*opacity)))
    im=im.convert('RGBA')
    im.alpha_composite(f,(0,y))
    return im

def glow(im,x,y,r=95,power=.7,color=(244,177,81)):
    # A soft, independently animated pool of lamplight.
    r=max(10,int(r))
    yy,xx=np.mgrid[-64:64,-64:64]
    alpha=np.exp(-(xx*xx+yy*yy)/(2*21**2))*65*power
    arr=np.zeros((128,128,4),dtype=np.uint8)
    arr[:,:,:3]=color
    arr[:,:,3]=np.clip(alpha,0,130).astype('uint8')
    layer=Image.fromarray(arr).resize((r*2,r*2),Image.Resampling.BILINEAR)
    im=im.convert('RGBA')
    im.alpha_composite(layer,(int(x-r),int(y-r)))
    return im

def beam(im,origin,target,t):
    # Low-resolution volumetric beam plus a moving illuminated snow patch.
    low=Image.new('RGBA',(W//4,H//4))
    d=ImageDraw.Draw(low)
    ox,oy=origin[0]/4,origin[1]/4
    tx,ty=target[0]/4,target[1]/4
    d.polygon([(ox,oy),(tx-26,ty),(tx+26,ty+9)],fill=(210,216,183,19))
    low=low.filter(ImageFilter.GaussianBlur(8)).resize((W,H),Image.Resampling.BILINEAR)
    im=Image.alpha_composite(im.convert('RGBA'),low)
    return glow(im,target[0],target[1],105,.40,(211,219,189))

@lru_cache(maxsize=40)
def walker(frame):
    p=ROOT/'blender/frames'/f'hikers_{frame+1:04}.png'
    im=Image.open(p).convert('RGBA')
    a=np.array(im)
    # Workbench model becomes a subtle distant silhouette; the lamp stays warm.
    lamp=(a[:,:,0]>90)&(a[:,:,0]>a[:,:,2]*1.7)
    rgb=(a[:,:,:3].astype('float32')*.27+np.array([3,8,11])).astype('uint8')
    rgb[lamp]=np.array([194,142,61])
    a[:,:,:3]=rgb
    return Image.fromarray(a)

def hikers(im,t,shot,n=4,lantern=False,close=False):
    im=im.convert('RGBA')
    ground=Image.new('RGBA',(W,H))
    d=ImageDraw.Draw(ground)
    specs=[]
    for j in range(n):
        if close:
            h=220-j*25
            x=130+j*125+t*9
            feet=950-j*32+t*2
        elif shot<2 or n>5:
            h=95+j*5 if n>5 else 175-j*18
            x=60+j*(65 if n>5 else 130)+t*14
            feet=(660+j*22 if n>5 else 755+j*5)-t*2
        else:
            h=185-j*35
            x=235+j*93+t*(7-j)
            feet=975-j*105-t*6
        w=round(h/2)
        d.ellipse((x-w*.36,feet-3,x+w*.36,feet+6),fill=(4,12,21,92))
        specs.append((x,feet,w,h,j))
    im=Image.alpha_composite(im,ground.filter(ImageFilter.GaussianBlur(3)))
    for x,feet,w,h,j in reversed(specs):
        frame=(int(t*FPS)+j*7+shot*3)%32
        sprite=walker(frame).resize((w,h),Image.Resampling.LANCZOS)
        im.alpha_composite(sprite,(int(x-w/2),int(feet-h)))
        if lantern:
            lx=x-w*.29+math.sin(t*4.71+j)*4
            ly=feet-h*.39
            im=glow(im,lx,ly,40+h*.18,.7+.1*math.sin(t*14+j))
            ImageDraw.Draw(im).ellipse((lx-1,ly-1,lx+2,ly+3),fill=(244,198,114,230))
            if j==0:
                im=beam(im,(lx,ly),(x+60*math.sin(t*.8),feet+45),t)
    return im

@lru_cache(maxsize=6)
def tent_asset(width):
    im=Image.open(ASSETS/'tent.png').convert('RGBA')
    a=im.getchannel('A')
    # Low-alpha atmospheric halo is discarded; canvas and ropes stay sharp.
    a=a.point(lambda v:0 if v<42 else v)
    im.putalpha(a)
    return im.resize((width,round(im.height*width/im.width)),Image.Resampling.LANCZOS)

def ripple(im,t,amount=5,interior=False):
    w,h=im.size
    mesh=[]
    cols,rows=12,14
    def point(x,y):
        nx,ny=x/w,y/h
        weight=(1-ny)*(.3+.7*math.sin(math.pi*nx))
        if interior:
            weight=max(0,1-nx/.66)*math.sin(math.pi*ny)
        dx=amount*math.sin(ny*14+t*5+nx*3)*weight
        dy=amount*.35*math.sin(nx*15+t*7)*weight
        return x+dx,y+dy
    for row in range(rows):
        for col in range(cols):
            x0,x1=round(col*w/cols),round((col+1)*w/cols)
            y0,y1=round(row*h/rows),round((row+1)*h/rows)
            quad=(*point(x0,y0),*point(x0,y1),*point(x1,y1),*point(x1,y0))
            mesh.append(((x0,y0,x1,y1),quad))
    return im.transform(im.size,Image.Transform.MESH,mesh,Image.Resampling.BILINEAR)

def camp(im,t,shot):
    im=im.convert('RGBA')
    width=665 if shot==2 else 800
    tent=tent_asset(width)
    tent=ripple(tent,t,6)
    x=(W-width)//2+int(4*math.sin(t*.4))
    y=480 if shot==2 else 380
    shadow=Image.new('RGBA',(W,H))
    ImageDraw.Draw(shadow).ellipse((x+25,y+tent.height*.75,x+width-20,y+tent.height+22),fill=(3,8,16,115))
    im=Image.alpha_composite(im,shadow.filter(ImageFilter.GaussianBlur(18)))
    im.alpha_composite(tent,(x,y))
    im=glow(im,x+width*.29,y+tent.height*.65,110,.45+.12*math.sin(t*11)+.08*math.sin(t*19))
    return im

def tracks(im,t):
    layer=Image.new('RGBA',(W,H))
    d=ImageDraw.Draw(layer)
    # Perspective track: successive impressions are uncovered by drifting snow.
    for k in range(18):
        u=k/18
        y=1160-u*440
        xx=350+55*math.sin(u*1.6)+(1 if k%2 else -1)*(17-12*u)
        r=13-10*u
        alpha=int(125*min(1,max(0,t*5-k+5)))
        d.ellipse((xx-r*.48,y-r,xx+r*.48,y+r),fill=(22,40,56,alpha))
        d.arc((xx-r*.7,y-r,xx+r*.7,y+r),0,180,fill=(160,181,196,int(alpha*.6)),width=1)
    return Image.alpha_composite(im.convert('RGBA'),layer.filter(ImageFilter.GaussianBlur(.45)))

def avalanche(im,t,variant):
    im=im.convert('RGBA')
    overlay=Image.new('RGBA',(W,H))
    d=ImageDraw.Draw(overlay)
    shift=max(0,t-.65)**1.7*18
    top=395+shift
    polygon=[(170+shift*.2,top),(580+shift*.2,top+155),(650+shift*.2,top+360),(240+shift*.2,top+205)]
    mask=Image.new('L',(W,H))
    ImageDraw.Draw(mask).polygon(polygon,fill=230)
    mask=mask.filter(ImageFilter.GaussianBlur(1.5))
    moving=im.transform(im.size,Image.Transform.AFFINE,(1,0,-shift*.2,0,1,-shift),Image.Resampling.BILINEAR)
    im.paste(moving,(0,0),mask)
    d.line([polygon[0],polygon[1]],fill=(231,240,244,155),width=2)
    d.line([(170,395),(580,550)],fill=(21,38,48,180),width=3)
    rng=np.random.default_rng(51)
    for x,y,speed in rng.uniform([170,395,25],[640,730,80],size=(100,3)):
        move=max(0,t-.6)*speed
        px=x+move*.35
        py=y+move
        if py<1100:
            d.ellipse((px,py,px+3,py+1.5),fill=(221,233,236,110))
    im=Image.alpha_composite(im,overlay)
    lab=ImageDraw.Draw(im)
    lab.text((45,160),'СХЕМАЛЫҚ МОДЕЛЬ',font=font(13),fill=(210,221,228,230))
    return im

def branches(im,t):
    layer=Image.new('RGBA',(W,H))
    d=ImageDraw.Draw(layer)
    sway=7*math.sin(t*1.6)
    for side in [0,1]:
        edge=-20 if side==0 else W+20
        direction=1 if side==0 else -1
        for j in range(7):
            yy=180+j*98
            tip=edge+direction*(48+(j%3)*32)+sway*(j+2)/9
            d.line((edge,yy,tip,yy+58),fill=(5,13,20,205),width=5)
            for k in range(7):
                x=edge+(tip-edge)*k/7
                y=yy+58*k/7
                d.line((x,y,x+direction*22,y-16),fill=(7,18,26,215),width=2)
                d.line((x,y,x+direction*15,y+19),fill=(7,18,26,210),width=2)
    return Image.alpha_composite(im.convert('RGBA'),layer)

@lru_cache(maxsize=32)
def text_layer(index):
    item=TIMELINE[index]
    layer=Image.new('RGBA',(W,H))
    d=ImageDraw.Draw(layer)
    badge=item['badge']
    bfont=font(13)
    box=d.textbbox((0,0),badge,font=bfont)
    d.rounded_rectangle((42,73,58+box[2],99),radius=2,fill=(6,10,13,155))
    d.text((50,77),badge,font=bfont,fill=(233,232,217,255))
    size=30
    lines=item['caption'].split('\n')
    while max(d.textlength(line,font=font(size,True)) for line in lines)>W-92:
        size-=1
    f=font(size,True)
    for j,line in enumerate(lines):
        width=d.textlength(line,font=f)
        pos=((W-width)/2,876+j*(size+11))
        d.text((pos[0]+1,pos[1]+2),line,font=f,fill=(0,0,0,230),stroke_width=3,stroke_fill=(0,0,0,130))
        d.text(pos,line,font=f,fill=(247,244,232,255))
    d.text((43,1180),'AI-РЕКОНСТРУКЦИЯ · КӨРКЕМ БЕЙНЕ',font=font(11),fill=(198,205,203,185))
    return layer

def frame(index,n):
    t=n/FPS
    typ=TIMELINE[index]['scene_type']
    if typ=='document':
        from graphics import render_document
        im=render_document(t,index-8,W,H).convert('RGBA')
    elif typ=='diagram':
        from graphics import render_diagram
        im=render_diagram(t,0 if index==12 else 1,W,H).convert('RGBA')
    else:
        base='forest' if typ in ['forest','search','footprints','boots'] else 'inside' if typ=='inside' else 'ridge'
        im=camera(photo(base),t,index).convert('RGBA')
        if typ=='hiking':
            im=hikers(im,t,index,9 if index==0 else 3,False,index==1)
        elif typ=='tent':
            im=camp(im,t,index)
        elif typ=='inside':
            im=ripple(im,t,6,True)
            im=glow(im,638,947,230,.75+.16*math.sin(t*13)+.10*math.sin(t*22))
        elif typ in ['forest','search','boots']:
            im=hikers(im,t,index,3,True,typ=='boots')
            im=branches(im,t)
        elif typ=='footprints':
            im=tracks(im,t)
            im=branches(im,t)
        elif typ=='snow_slab':
            im=avalanche(im,t,index)
        elif typ=='dawn':
            if index==17:
                im=hikers(im,t,index,9)
            im=glow(im,420,210,420,.35,(236,182,119))
        if typ!='inside':
            im=fog(im,t+index*.8,630 if base=='ridge' else 700,.7)
        im=snow(im,t+index*.45,1.25 if typ in ['tent','snow_slab'] else .55 if typ=='dawn' else .8,typ!='inside')
    im=Image.alpha_composite(im,vignette())
    # Keep the opening uninterrupted by a cover slide: captions sit over action.
    layer=text_layer(index)
    strength=min(1,t/.15)
    if strength<1:
        layer=layer.copy()
        layer.putalpha(layer.getchannel('A').point(lambda a:int(a*strength)))
    im=Image.alpha_composite(im,layer)
    if index==17 and t>3:
        im=Image.blend(Image.new('RGBA',(W,H),(0,0,0,255)),im,max(0,(4-t)))
    return im.convert('RGB')

def render_clip(index):
    path=OUT/f'clip_{index:02}.mp4'
    log=(OUT/f'clip_{index:02}.log').open('w')
    command=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-an','-vf','noise=alls=2:allf=t','-c:v','libx264','-preset','fast','-crf','20','-threads','1','-pix_fmt','yuv420p','-movflags','+faststart',str(path)]
    proc=subprocess.Popen(command,stdin=subprocess.PIPE,stderr=log)
    start=time.monotonic()
    try:
        for n in range(FPS*4):
            proc.stdin.write(frame(index,n).tobytes())
        proc.stdin.close()
        code=proc.wait()
        if code:
            raise RuntimeError(f'FFmpeg failed for clip {index}, see {log.name}')
    except BaseException:
        proc.kill()
        proc.wait()
        raise
    finally:
        log.close()
    print(f'clip {index:02} {TIMELINE[index]["scene_type"]}: {time.monotonic()-start:.1f}s',flush=True)
    return path

def finish():
    concat=OUT/'sequence.ffconcat'
    concat.write_text('ffconcat version 1.0\n'+''.join(f"file 'clip_{i:02}.mp4'\n" for i in range(18)))
    target=OUT/'dyatlov_kk_animated_v2.mp4'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(ROOT/'sound/soundscape.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','72','-movflags','+faststart','-metadata','title=Дятлов асуы — анимациялық реконструкция','-metadata','comment=Original AI still assets combined with procedural layered animation and articulated 3D hiker sprites. No generative video model and no spoken narration.',str(target)],check=True)
    print(target,flush=True)

def previews():
    OUT.mkdir(exist_ok=True)
    for i in range(18):
        frame(i,48).save(OUT/f'preview_{i:02}.jpg',quality=92)
    image=Image.new('RGB',(240*6,427*3))
    for i in range(18):
        image.paste(Image.open(OUT/f'preview_{i:02}.jpg').resize((240,427)),((i%6)*240,(i//6)*427))
    image.save(OUT/'contact.jpg',quality=93)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--preview',action='store_true')
    parser.add_argument('--clips',nargs='*',type=int)
    parser.add_argument('--finish',action='store_true')
    args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    if args.preview:
        previews()
    elif args.finish:
        finish()
    else:
        targets=args.clips if args.clips else list(range(18))
        with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
            list(pool.map(render_clip,targets))
        if args.clips is None:
            finish()
