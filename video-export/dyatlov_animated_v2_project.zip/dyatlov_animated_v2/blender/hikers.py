"""Headless procedural 3D walking searchers; no external models or textures."""
import bpy
import math
import os
import sys
from pathlib import Path
from mathutils import Vector

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'frames'
OUT.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

def mat(name,color):
    m=bpy.data.materials.new(name)
    m.diffuse_color=(*color,1)
    return m

coat=mat('Weathered navy wool',(0.033,0.049,0.060))
boots=mat('Black leather boots',(0.014,0.019,0.023))
pack=mat('Dark olive canvas pack',(0.070,0.075,0.057))
skin=mat('Face in hood shadow',(0.072,0.061,0.051))
lamp=mat('Warm lantern glass',(0.98,0.59,0.12))
metal=mat('Lantern frame',(0.080,0.070,0.050))

def sphere(name,loc,scale,material):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,location=loc)
    o=bpy.context.object;o.name=name;o.scale=scale
    o.data.materials.append(material)
    for p in o.data.polygons:p.use_smooth=True
    return o

def capsule(name,material,radius=0.06):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=10,ring_count=6)
    o=bpy.context.object;o.name=name;o.data.materials.append(material)
    for p in o.data.polygons:p.use_smooth=True
    o['radius']=radius
    return o

def line(o,a,b,r=None):
    a,b=Vector(a),Vector(b)
    v=b-a;o.location=(a+b)/2
    o.rotation_euler=v.to_track_quat('Z','Y').to_euler()
    radius=r or o['radius']
    o.scale=(radius,radius,v.length/2+radius*0.55)

class Hiker:
    def __init__(self,n,offset,phase):
        self.offset=Vector(offset);self.phase=phase
        self.torso=sphere(f'{n} coat',(0,0,0),(0.24,0.18,0.40),coat)
        self.skirt=sphere(f'{n} coat skirt',(0,0,0),(0.255,0.185,0.36),coat)
        self.hood=sphere(f'{n} hood',(0,0,0),(0.16,0.155,0.20),coat)
        self.face=sphere(f'{n} shadowed face',(0,0,0),(0.105,0.035,0.13),skin)
        self.hat=sphere(f'{n} cap',(0,0,0),(0.155,0.15,0.055),coat)
        self.pack=sphere(f'{n} backpack',(0,0,0),(0.23,0.12,0.31),pack)
        self.limbs={k:capsule(n+k,coat if 'arm' in k else boots,0.072 if 'arm' in k else 0.068)
                    for k in ['armL1','armL2','armR1','armR2','legL1','legL2','legR1','legR2']}
        self.feet=[sphere(n+' boot',(0,0,0),(0.09,0.17,0.08),boots) for _ in range(2)]
        self.hands=[sphere(n+' mitten',(0,0,0),(0.075,0.075,0.09),boots) for _ in range(2)]
        self.light=sphere(n+' lantern',(0,0,0),(0.060,0.060,0.090),lamp)
        self.light_top=sphere(n+' lantern cap',(0,0,0),(0.070,0.070,0.025),metal)
    def update(self,t):
        phase=t*2*math.pi*0.75+self.phase
        pos=self.offset
        bob=0.018*math.cos(phase*2)
        self.torso.location=pos+Vector((0,0,1.19+bob))
        self.torso.rotation_euler[0]=math.radians(-6)
        self.skirt.location=pos+Vector((0,0,0.99+bob))
        self.hood.location=pos+Vector((0,-0.025,1.72+bob))
        self.face.location=pos+Vector((0,-0.15,1.72+bob))
        self.hat.location=pos+Vector((0,-0.015,1.875+bob))
        self.pack.location=pos+Vector((0,0.205,1.29+bob))
        for side,sign in enumerate([-1,1]):
            p=phase+side*math.pi
            hip=pos+Vector((sign*0.115,0,0.94+bob))
            swing=0.30*math.sin(p)
            knee=hip+Vector((0,-0.10-math.sin(swing)*0.40,-math.cos(swing)*0.40))
            bend=max(0,math.cos(p))*0.6
            ankle=knee+Vector((0,math.sin(bend-swing)*0.38,-math.cos(bend-swing)*0.38))
            ankle.z=max(0.09,ankle.z)
            key='L' if side==0 else 'R'
            line(self.limbs['leg'+key+'1'],hip,knee,0.085)
            line(self.limbs['leg'+key+'2'],knee,ankle,0.065)
            self.feet[side].location=ankle+Vector((0,-0.07,-0.02))
            self.feet[side].rotation_euler[0]=-0.15*max(0,math.cos(p))
            shoulder=pos+Vector((sign*0.235,0,1.48+bob))
            elbow=shoulder+Vector((sign*0.045,math.sin(p)*0.115,-0.30))
            hand=elbow+Vector((sign*0.015,-0.07+math.sin(p)*0.075,-0.25))
            line(self.limbs['arm'+key+'1'],shoulder,elbow,0.092)
            line(self.limbs['arm'+key+'2'],elbow,hand,0.072)
            self.hands[side].location=hand
            if side==1:
                self.light.location=hand+Vector((0,0,-0.17))
                self.light_top.location=hand+Vector((0,0,-0.075))

hikers=[Hiker('Searcher',(0,0,0),0)]
bpy.ops.object.camera_add(location=(3.6,8.0,2.3))
cam=bpy.context.object
cam.data.type='ORTHO';cam.data.ortho_scale=2.16
target=Vector((0,0,1.00))
cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
scene=bpy.context.scene
scene.camera=cam
scene.render.engine='BLENDER_WORKBENCH'
scene.render.film_transparent=True
scene.display.shading.light='STUDIO'
scene.display.shading.studiolight_rotate_z=math.radians(40)
scene.display.shading.color_type='MATERIAL'
scene.display.shading.show_shadows=True
scene.display.shading.show_cavity=True
scene.display.shading.cavity_type='BOTH'
scene.display.shading.curvature_ridge_factor=1.4
scene.display.shading.curvature_valley_factor=1.2
scene.display.shading.show_specular_highlight=False
scene.display.render_aa='FXAA'
scene.render.resolution_x=256;scene.render.resolution_y=512
scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.render.image_settings.color_mode='RGBA'
scene.render.fps=24
scene.render.threads_mode='FIXED';scene.render.threads=2
scene.view_settings.view_transform='Standard'
scene.world.color=(0.06,0.08,0.10)
scene.frame_start=1;scene.frame_end=32

mode=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
frames=[1,9] if 'test' in mode else range(1,33)
for f in frames:
    scene.frame_set(f)
    t=(f-1)/24
    for h in hikers:h.update(t)
    scene.render.filepath=str(OUT/f'hikers_{f:04}.png')
    bpy.ops.render.render(write_still=True)

if 'test' not in mode:
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'hikers.blend'))
