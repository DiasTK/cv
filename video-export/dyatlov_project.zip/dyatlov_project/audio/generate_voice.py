#!/usr/bin/env python3
"""Generate Kazakh narration using Edge TTS after its destination is allowed.

Run with the project-local interpreter:
  .venv/bin/python generate_voice.py
No credentials are stored. Existing HTTPS proxy configuration is used.
"""
import asyncio
import json
import os
from pathlib import Path
import subprocess
import edge_tts

ROOT = Path(__file__).resolve().parent

async def main():
    manifest_path = ROOT / 'narration.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    for segment in manifest['segments']:
        output = ROOT / segment['audio_file']
        temporary = output.with_suffix('.part.mp3')
        try:
            communicate = edge_tts.Communicate(
                segment['text'], voice=manifest['voice'],
                rate='-5%', pitch='-3Hz',
                proxy=os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy'),
                connect_timeout=10, receive_timeout=30,
            )
            await communicate.save(str(temporary))
            duration = float(subprocess.check_output([
                'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                '-of', 'default=noprint_wrappers=1:nokey=1', str(temporary)
            ], text=True).strip())
            if duration <= 0 or temporary.stat().st_size < 1024:
                raise RuntimeError('Invalid generated audio')
            temporary.replace(output)
            segment['measured_duration'] = duration
            print(f"Saved scene {segment['index']:02}: {duration:.2f} seconds")
        except Exception as exc:
            temporary.unlink(missing_ok=True)
            status = getattr(exc, 'status', None)
            print(f"Generation failed: {type(exc).__name__}" + (f"; HTTP {status}" if status else ''))
            print('Check access to speech.platform.bing.com. TLS verification remains enabled.')
            raise SystemExit(1)
    manifest['status'] = 'generated'
    manifest.pop('blocker', None)
    manifest['timing_note'] = 'Measured durations are recorded per scene; editorial timings require resynchronization before mixing.'
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

if __name__ == '__main__':
    asyncio.run(main())
