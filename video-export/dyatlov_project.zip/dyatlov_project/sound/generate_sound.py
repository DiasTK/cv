#!/usr/bin/env python3
"""Synthesize an original winter-documentary ambience. No external samples."""
from pathlib import Path
import json
import wave
import numpy as np
from scipy.signal import butter, sosfilt

ROOT = Path(__file__).resolve().parent
SR = 48_000
SECONDS = 90
N = SR * SECONDS
rng = np.random.default_rng(1959)
t = np.arange(N, dtype=np.float64) / SR


def filtered_noise(low, high):
    sos = butter(3, [low, high], btype="bandpass", fs=SR, output="sos")
    a = sosfilt(sos, rng.standard_normal(N))
    return a / np.sqrt(np.mean(a * a))


# Breathing gusts move slowly across the stereo field. Keep the midrange clear
# enough to add narration later without replacing the atmosphere.
gust = (0.66 + 0.18 * np.sin(2 * np.pi * 0.043 * t + 0.4)
        + 0.09 * np.sin(2 * np.pi * 0.113 * t))
arc = np.interp(t, [0, 9, 15, 29, 44, 58, 69, 78, 90],
                [0.64, 0.73, 0.80, 0.87, 0.86, 1.0, 0.94, 0.75, 0.42])
core = filtered_noise(70, 920) * gust * arc
air_l = filtered_noise(430, 2800)
air_r = filtered_noise(430, 2800)
pan = 0.10 * np.sin(2 * np.pi * 0.031 * t)
left = 0.048 * core * (1.0 + pan) + 0.007 * air_l * gust
right = 0.048 * core * (1.0 - pan) + 0.007 * air_r * gust

# A quiet, warm low register under the cold wind: A1 / E2, no melody.
drone = (0.017 * np.sin(2 * np.pi * 55.0 * t + 0.20 * np.sin(t * 0.13))
         + 0.008 * np.sin(2 * np.pi * 82.4069 * t + 0.23 * np.sin(t * 0.09))
         + 0.003 * np.sin(2 * np.pi * 110.0 * t))
drone *= (0.62 + 0.12 * np.sin(t * 0.19)) * arc
left += drone
right += drone


def add_event(at, duration, kind):
    start = int(at * SR)
    count = min(int(duration * SR), N - start)
    u = np.arange(count, dtype=np.float64) / SR
    if kind == "pulse":
        # Soft felt-like low pulse, not a jump scare.
        sig = 0.026 * np.sin(2 * np.pi * (64 * u - 2.6 * u * u))
        sig *= (1 - np.exp(-u * 100)) * np.exp(-u * 3.5)
    elif kind == "tick":
        sig = (0.0032 * np.sin(2 * np.pi * 1174.66 * u)
               + 0.0016 * np.sin(2 * np.pi * 1762.0 * u))
        sig *= (1 - np.exp(-u * 180)) * np.exp(-u * 7)
    else:
        sig = sosfilt(butter(2, [110, 730], btype="bandpass", fs=SR,
                            output="sos"), rng.standard_normal(count))
        sig *= 0.022 * np.sin(np.pi * u / duration) ** 2
    left[start:start+count] += sig
    right[start:start+count] += sig * 0.96


for at in [1.0, 14.8, 29.8, 44.8, 59.8, 74.8]:
    add_event(at, 2.3, "pulse")
for at in [8.8, 23.8, 38.8, 53.8, 68.8]:
    add_event(at, 1.0, "tick")
for at in [13.6, 28.6, 43.6, 58.6, 73.6]:
    add_event(at, 2.2, "swell")

fade = np.minimum(np.clip(t / 2.5, 0, 1), np.clip((SECONDS - t) / 4.5, 0, 1))
fade = np.sin(fade * np.pi / 2) ** 2
audio = np.column_stack([left * fade, right * fade])
target_rms = 10 ** (-22.0 / 20)
audio *= target_rms / np.sqrt(np.mean(audio ** 2))
peak = np.max(np.abs(audio))
limit = 10 ** (-3 / 20)
if peak > limit:
    audio *= limit / peak
pcm = np.rint(audio * 32767).astype("<i2")
out = ROOT / "soundscape.wav"
with wave.open(str(out), "wb") as f:
    f.setnchannels(2)
    f.setsampwidth(2)
    f.setframerate(SR)
    f.writeframes(pcm.tobytes())
metrics = {
    "file": str(out),
    "duration_seconds": SECONDS,
    "sample_rate": SR,
    "channels": 2,
    "encoding": "PCM signed 16-bit little endian",
    "peak_dbfs": float(20 * np.log10(np.max(np.abs(audio)))),
    "rms_dbfs": float(20 * np.log10(np.sqrt(np.mean(audio ** 2)))),
    "source": "Original deterministic synthesis; no licensed samples or vocals",
}
(ROOT / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
print(json.dumps(metrics, indent=2))
