#!/usr/bin/env python3
"""Render an original 90-second Kazakh documentary short using Pillow/FFmpeg."""
from pathlib import Path
import argparse
import concurrent.futures
import json
import math
import shutil
import subprocess
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
OUTPUT = ROOT / 'output'
W, H, FPS = 1080, 1920, 30
SHEET = ROOT / 'assets' / 'storyboard.png'
FONT = str(ASSETS / 'fonts' / 'NotoSans-Regular.ttf')
BOLD = str(ASSETS / 'fonts' / 'NotoSans-Bold.ttf')
WHITE = (240, 241, 232, 255)
MUTED = (163, 183, 194, 255)
GOLD = (214, 172, 101, 255)

SCENES = [
    ('1959 / СОЛТҮСТІК ОРАЛ', [
        ('ДЯТЛОВ\nАСУЫ', 'СОЛ ТҮНІ НЕ БОЛДЫ?', 'ДЕРЕКТЕР МЕН СҰРАҚТАР'),
        ('Тоғыз\nжорықшы.', 'Игорь Дятлов бастаған топ', 'ЕШҚАЙСЫСЫ ҮЙІНЕ ОРАЛМАДЫ'),
        ('Оларды шатырдан\nне шығарды?', '1959 жылғы қайғылы оқиға', 'ОҚИҒАНЫҢ ІЗІМЕН'),
    ]),
    ('01 / ТАБЫЛҒАН ШАТЫР', [
        ('Қарлы беткей.\nТасталған шатыр.', 'Іздеушілер топтың шатырын тапты.', '1959 / АҚПАН'),
        ('Шатыр ішкі\nжағынан кесілген.', 'Тергеу материалдарындағы дерек', 'ТЕРГЕУ ДЕРЕГІ'),
        ('Іздер орманға\nқарай кеткен.', 'Кейбір жорықшылар жылы киінбеген.', 'ШАТЫРДАН АЛЫСТАҒАН ТОП'),
    ]),
    ('02 / ОРМАНҒА КЕТКЕН ІЗДЕР', [
        ('Қатты аяз.\nҚараңғы орман.', 'Топ шатырдан алыстап кеткен.', 'СОЛТҮСТІК ОРАЛ'),
        ('Іздеу бірнеше\nайға созылды.', 'Соңғы төрт адамның денесі\nмамырда табылды.', '1959 / АҚПАН — МАМЫР'),
        ('Суық пен\nауыр жарақаттар.', 'Алтауы суықтан, үшеуі ауыр\nжарақаттан қаза тапқан.', 'САРАПТАМА ҚОРЫТЫНДЫСЫ'),
    ]),
    ('03 / ДЕРЕК ПЕН БОЛЖАМ', [
        ('Сұрақ көп.\nБолжам да көп.', 'Оқиға түрлі нұсқаның тарауына\nсебеп болды.', 'ДЕРЕК ПЕН ЖОРАМАЛ'),
        ('Қылмыс болғаны\nдәлелденбеген.', 'Болжам дәлелдің орнын баспайды.', 'ТЕРГЕУ ЖӘНЕ СҰРАҚТАР'),
        ('Тергеу табиғи\nкүшті атады.', 'Нақты оқиға барысы толық\nанықталмады.', '1959 / ТЕРГЕУ ҚОРЫТЫНДЫСЫ'),
    ]),
    ('04 / РЕСМИ ҚОРЫТЫНДЫ', [
        ('ҚАР\nКӨШКІНІ', 'Ресей прокуратурасының\n2020 жылғы қорытындысы', '2020 / РЕСМИ ТҮСІНДІРМЕ'),
        ('Қауіптен қашу.\nАязда қалу.', 'Ресми түсіндірмедегі оқиға желісі', 'ҚАР КӨШКІНІ НҰСҚАСЫ'),
        ('Ғылым осы\nнұсқаны зерттеді.', 'Модельдер оның болуы\nмүмкін екенін көрсетті.', 'ЫҚТИМАЛ ОҚИҒА МЕХАНИЗМІ'),
    ]),
    ('05 / СОЛ ТҮННІҢ СҰРАҚТАРЫ', [
        ('Оқиғаның реті\nәлі талқыланады.', 'Модель сол түннің әр сәтін\nтолық дәлелдемейді.', 'ДЕРЕКТЕР МЕН АШЫҚ СҰРАҚТАР'),
        ('Тоғыз адамның\nүзілген сапары.', 'Дятлов асуындағы қайғылы оқиға', '1959 / ЕСТЕ САҚТАУ'),
        ('ДЯТЛОВ\nАСУЫ', 'СОЛ ТҮНІ НЕ БОЛДЫ?', 'ДЕРЕКТІ ХИКАЯ / ҚАЗАҚША'),
    ]),
]

def run(args, **kw):
    return subprocess.run(args, check=True, **kw)

def font(size, bold=False):
    return ImageFont.truetype(BOLD if bold else FONT, size)

def fit_font(text, start, maxwidth=888):
    for size in range(start, 39, -2):
        f = font(size, True)
        if max(ImageDraw.Draw(Image.new('L',(1,1))).textlength(t,font=f) for t in text.split('\n')) <= maxwidth:
            return f
    raise ValueError('Title does not fit: '+text)

def text_at(draw, pos, text, f, fill, spacing=12):
    draw.multiline_text(pos, text, font=f, fill=fill, spacing=spacing, stroke_width=0)

def prepare():
    ASSETS.mkdir(exist_ok=True)
    OUTPUT.mkdir(exist_ok=True)
    sheet = Image.open(SHEET).convert('RGB')
    sw, sh = sheet.size
    timeline = []
    for i, (chapter, cards) in enumerate(SCENES):
        col, row = i % 3, i // 3
        photo = sheet.crop((round(col*sw/3), round(row*sh/2), round((col+1)*sw/3), round((row+1)*sh/2)))
        photo.save(ASSETS/f'photo_{i+1:02}.jpg',quality=96)
        # Sharp full-width photograph above a soft photographic extension.
        bg = photo.resize((1920,1920), Image.Resampling.LANCZOS).crop((420,0,1500,1920)).filter(ImageFilter.GaussianBlur(32))
        sharp = photo.resize((1250,1250),Image.Resampling.LANCZOS).crop((85,0,1165,1250))
        mask_a = np.ones((1250,W),dtype=np.float32)*255
        mask_a[990:] *= np.linspace(1,0,260)[:,None]
        bg.paste(sharp,(0,0),Image.fromarray(mask_a.astype('uint8')))
        a = np.zeros((H,W,4),dtype='uint8')
        a[:,:,0:3] = (5,13,22)
        a[:,:,3] = np.interp(np.arange(H),[0,200,700,1020,1260,1600,1919],[68,12,12,40,212,240,249])[:,None].astype('uint8')
        bg = Image.alpha_composite(bg.convert('RGBA'),Image.fromarray(a))
        bg.convert('RGB').save(ASSETS/f'background_{i+1:02}.jpg',quality=95)
        listing=['ffconcat version 1.0']
        for j,(title,sub,eyebrow) in enumerate(cards):
            layer = Image.new('RGBA',(W,H))
            d=ImageDraw.Draw(layer)
            # Safe margins for vertical social video; text sits clear of UI chrome.
            d.line((90,150,138,150),fill=GOLD,width=4)
            text_at(d,(156,130),'ДЕРЕКТІ ХИКАЯ',font(23,True),WHITE)
            text_at(d,(888,130),f'{i+1:02}/06',font(23),MUTED)
            text_at(d,(90,1125),eyebrow,font(22,True),GOLD)
            f=fit_font(title,104 if title.isupper() else 69)
            text_at(d,(84,1180),title,f,WHITE,8)
            title_bottom=1180 + len(title.split('\n'))*(f.size+8)
            text_at(d,(90,max(1435,title_bottom+28)),sub,font(31),MUTED,14)
            text_at(d,(90,1642),chapter,font(21),MUTED)
            # Six unobtrusive chapter markers.
            for k in range(6):
                x=90+k*151
                d.rounded_rectangle((x,1710,x+132,1714),radius=2,fill=GOLD if k<=i else (64,83,96,190))
            text_at(d,(90,1747),'КӨРКЕМ РЕКОНСТРУКЦИЯ · AI-ВИЗУАЛ',font(18),MUTED)
            path=ASSETS/f'title_{i+1:02}_{j+1:02}.png'
            layer.save(path)
            listing.extend([f"file '{path.name}'",'duration 5.0'])
            timeline.append({'start':i*15+j*5,'end':i*15+(j+1)*5,'chapter':chapter,'title':title,'subtitle':sub,'eyebrow':eyebrow})
            if j==0:
                preview=Image.alpha_composite(bg,layer).convert('RGB')
                preview.save(OUTPUT/f'preview_{i+1:02}.jpg',quality=93)
        listing.append(f"file 'title_{i+1:02}_03.png'")
        (ASSETS/f'titles_{i+1:02}.ffconcat').write_text('\n'.join(listing)+'\n')
    (ROOT/'timeline.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2))
    def stamp(t):
        return f'{int(t)//3600:02}:{int(t)//60%60:02}:{int(t)%60:02},000'
    srt='\n\n'.join(f"{n}\n{stamp(x['start'])} --> {stamp(x['end'])}\n{x['title']}\n{x['subtitle']}" for n,x in enumerate(timeline,1))
    (OUTPUT/'dyatlov_kk.srt').write_text(srt+'\n')
    shutil.copyfile(OUTPUT/'preview_01.jpg',OUTPUT/'cover.jpg')

def render_scene(i):
    target=OUTPUT/f'scene_{i+1:02}.mp4'
    # Small stable image-space motion; graphics remain fixed and readable.
    motion="zoompan=z='1.025+0.000065*on':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=1080x1920:fps=30"
    filt=f"[0:v]{motion},setsar=1[bg];[1:v]fps=30,format=rgba[txt];[bg][txt]overlay=0:0:shortest=1,noise=alls=1:allf=t,fade=t=in:st=0:d=0.45,fade=t=out:st=14.5:d=0.5,format=yuv420p[v]"
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-threads','2','-filter_complex_threads','1','-loop','1','-framerate','30','-i',str(ASSETS/f'background_{i+1:02}.jpg'),'-f','concat','-safe','0','-i',str(ASSETS/f'titles_{i+1:02}.ffconcat'),'-filter_complex',filt,'-map','[v]','-t','15','-an','-c:v','libx264','-preset','fast','-crf','21','-threads','2','-pix_fmt','yuv420p','-r','30','-movflags','+faststart',str(target)]
    run(cmd)
    print(f'Rendered {target.name}',flush=True)
    return target

def finish():
    listing=OUTPUT/'scenes.ffconcat'
    listing.write_text('ffconcat version 1.0\n'+''.join(f"file 'scene_{i+1:02}.mp4'\n" for i in range(6)))
    target=OUTPUT/'dyatlov_kk_1080x1920.mp4'
    run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(listing),'-i',str(ROOT/'sound/soundscape.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t','90','-metadata','title=Дятлов асуы: сол түні не болды?','-metadata','comment=Original AI visual reconstructions; Kazakh on-screen narrative; original synthesized soundscape; no spoken narration.','-metadata:s:a:0','language=und','-movflags','+faststart',str(target)])
    print(target,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--prepare-only',action='store_true')
    args=parser.parse_args()
    prepare()
    if not args.prepare_only:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(render_scene,range(6)))
        finish()
